from django.apps import AppConfig


class MystorageConfig(AppConfig):
    name = 'mystorage'
